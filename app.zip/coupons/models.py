# coupons/models.py
from django.db import models
from django.contrib.auth.models import User

class Coupon(models.Model):
    code = models.CharField(max_length=20, unique=True)
    discount_percent = models.FloatField()
    valid_from = models.DateTimeField()
    valid_until = models.DateTimeField()
    active = models.BooleanField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, db_column='created_by', to_field='id')
    usage_limit_per_user = models.IntegerField(default=1)

    def __str__(self):
        return self.code


from django.shortcuts import render
from django.http import JsonResponse
from django.utils import timezone
from .models import Coupon

def index(request):
    """
    View to render the main page with the popup.
    """
    return render(request, 'coupons/index.html')

def get_active_coupon(request):
    """
    View to fetch the active coupon and return it as JSON.
    """
    # Retrieve the first active coupon within the valid date range
    coupon = Coupon.objects.filter(
        active=True,
        valid_from__lte=timezone.now(),
        valid_until__gte=timezone.now()
    ).first()

    # Prepare the coupon data for JSON response
    if coupon:
        data = {
            'code': coupon.code,
            'discount_percent': coupon.discount_percent
        }
    else:
        data = {}

    return JsonResponse(data)


# coupon_project/urls.py
from django.contrib import admin
from django.urls import path
from coupons import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('get-active-coupon/', views.get_active_coupon, name='get_active_coupon'),
]

